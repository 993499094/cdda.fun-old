中文字库+菜单汉化
字体: 开源点阵字体超越宋体Zfull-GB

tools文件夹内包含:
中文字库配置预设
-Aground.bmfc
自己汉化了菜单的开源程序bmfont64
-bmfont64_CHS.exe
开源点阵字体超越宋体Zfull-GB
-Zfull-GB.ttf

*欢迎大佬们自提补全汉化~