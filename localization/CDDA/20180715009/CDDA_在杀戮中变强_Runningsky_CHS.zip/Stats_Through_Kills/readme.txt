Originally found on japanese wiki in a broken state.  Translated with google translate, fixed so it worked, and added some features.

On creating a character, it will open a configuration menu.  First pick if you want your stat points to be chosen at random, chosen by you, or assigned equally to all stats.

If you decide you want to pick, it will then ask you for anti-oops settings -- this is to prevent you from accidentally assigning your stats, such as if you are holding 2 when it opens the menu.  It is recommended to set it to at least 2, as it has been set to never pick the same number that you picked on the next run.

Afterwards, you will get a menu showing an example of how many kills you need for the first five stat points.  From this screen, you can choose to open menus to set the initial kills per stat and the additional per stat.  Initial kills cannot go below 1, but additional can be set to 0 if desired for a flat X kills per stat increase, instead of an ever-increasing number of kills.  Once you close this menu, you cannot return back to it without save editing, so make sure you are happy with your choice before you hit done.

To add to an existing world, edit mods.json and include "StatsThroughKills" at the end, making sure the entry before it has a comma at the end.  The first time the script fires (daily) it will open the configuration menu, and then it will consider all your kills so far and determine if it needs to give you additional stats or not.

最初在破碎状态下在日本维基上发现。翻译谷歌翻译，修复，所以它的工作，并添加了一些功能。

在创建角色时，它会打开一个配置菜单。首先选择是否希望随机选择您的统计信息点，由您选择或平均分配给所有统计信息。

如果你决定要选择，它会问你反哎呀设置 - 这是为了防止你意外地分配你的统计信息，比如你打开菜单时拿着2。建议将其设置为至少2，因为它已被设置为从不选择与您在下次运行中选择的相同数字。

之后，您将看到一个菜单，其中显示了前五个统计点需要击杀多少个例子。在此屏幕上，您可以选择打开菜单来设置每个属性的初始杀伤数和每个属性的附加值。最初的杀戮不能低于1，但如果需要的话，额外可以设置为0，每杀死一个单位就可以杀死单位X，而不是杀死数量不断增加。关闭此菜单后，如果不进行保存编辑，则无法返回到该菜单，因此在完成之前请确保您满意您的选择。

要添加到现有世界中，请编辑mods.json，并在最后包含“StatsThroughKills”，确保输入最后有一个逗号。脚本第一次触发（每日）它会打开配置菜单，然后它会考虑到目前为止的所有杀死行为，并确定是否需要给你额外的统计信息。